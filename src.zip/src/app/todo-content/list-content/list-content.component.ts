import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TareaService } from '../../tarea.service';
import { PersonaService } from '../../persona.service';

@Component({
  selector: 'app-list-content',
  templateUrl: './list-content.component.html',
  styleUrls: ['./list-content.component.css']
})
export class ListContentComponent implements OnInit {
  private personas = [];
  private _tareas = [];
  private tareasFiltradas=[];
  private filtro={
    tarea:'',
    realizada: false
  };

  constructor(private tareaService: TareaService,
              private personaService: PersonaService) { }

  async ngOnInit() {
    var padreThis = this;
    this.tareaService.notificarCambio.subscribe(function(respuesta){
      padreThis._tareas = respuesta.tareas;
      padreThis.filtrarTareas();
    });

    this.personas = await this.personaService.traerTodasLasPersonas();
    await this.tareaService.todasLasTareas();
    //this.filtrarTareas();
  }

  filtrarTareas(){
    this.tareasFiltradas.splice(0, this.tareasFiltradas.length);
    this._tareas.forEach(unaTarea => {
      if(unaTarea.realizada == this.filtro.realizada && unaTarea.tarea.includes(this.filtro.tarea)){
        this.tareasFiltradas.push(unaTarea);
        console.log('agregabdo');
      }
    });
    this.convertirPersona();
  }

  convertirPersona(){
    this.tareasFiltradas.forEach(unaTarea => {
      this.personas.forEach(unaPersona => {
        if(unaPersona.id == unaTarea.asignado_a_id) {
          unaTarea.persona={nombre: unaPersona.nombre,
                            apellido: unaPersona.apellido,
                            id: unaPersona.id};
        }
      });
    });
    
  }

  async realizada(unaTarea) {
    let result: any;

    let tareaRealizada = {
      id: unaTarea.id,
      tarea: unaTarea.tarea,
      asignado_a_id: unaTarea.asignado_a_id,
      vencimiento: unaTarea.vencimiento,
      realizada: true,
      fecha_realizacion: new Date()
    }
    result = await this.tareaService.marcarFinalizada(tareaRealizada);

  }



}
